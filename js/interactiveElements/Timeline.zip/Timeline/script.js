const itemOne = document.getElementById("firstTimelineItem");
const itemTwo = document.getElementById("secondTimelineItem");
const itemThree = document.getElementById("thirdTimelineItem");
const itemFour = document.getElementById("fourthTimelineItem");
const itemFive = document.getElementById("fifthTimelineItem");
const itemSix = document.getElementById("sixthTimelineItem");
const itemSeven = document.getElementById("seventhTimelineItem");

/**
 * Checks each timeline item and determines whether to show it
 */
function checkVisibility() {
  if (itemOne.getBoundingClientRect().top < window.innerHeight - 100) {
    itemOne.classList.add("show");
  }
  if (itemTwo.getBoundingClientRect().top < window.innerHeight - 100) {
    itemTwo.classList.add("show");
  }
  if (itemThree.getBoundingClientRect().top < window.innerHeight - 100) {
    itemThree.classList.add("show");
  }
  if (itemFour.getBoundingClientRect().top < window.innerHeight - 100) {
    itemFour.classList.add("show");
  }
  if (itemFive.getBoundingClientRect().top < window.innerHeight - 100) {
    itemFive.classList.add("show");
  }
  if (itemSix.getBoundingClientRect().top < window.innerHeight - 100) {
    itemSix.classList.add("show");
  }
  if (itemSeven.getBoundingClientRect().top < window.innerHeight - 100) {
    itemSeven.classList.add("show");
  }
}

/**
 * Every time we load the page or scroll,
 * we need to check if the timeline items should be visible
 */
window.addEventListener("scroll", checkVisibility);
window.addEventListener("load", checkVisibility);
