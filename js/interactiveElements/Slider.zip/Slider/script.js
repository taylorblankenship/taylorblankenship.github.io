const slider = document.getElementById("slider");
const imageOne = document.getElementById("image1");
const imageTwo = document.getElementById("image2");
const imageThree = document.getElementById("image3");

changeDetected(slider);
function updateImage(num) {
  imageOne.classList.remove("active");
  imageTwo.classList.remove("active");
  imageThree.classList.remove("active");
  document.getElementById("image" + num).classList.add("active");
}
function changeDetected(input) {
  const value = input.value;
  if (value > 66) {
    updateImage(3);
  } else if (value > 33) {
    updateImage(2);
  } else {
    updateImage(1);
  }
}
