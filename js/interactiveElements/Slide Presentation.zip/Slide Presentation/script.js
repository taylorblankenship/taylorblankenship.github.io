var currentSlide = 1;

function showSlide(n) {
  // Hide all slides
  document.getElementById("slide1").classList.remove("active");
  document.getElementById("slide2").classList.remove("active");
  document.getElementById("slide3").classList.remove("active");

  // Show current slide
  document.getElementById("slide" + n).classList.add("active");
}

function nextSlide() {
  currentSlide++;
  if (currentSlide > 3) {
    currentSlide = 1;
  }
  showSlide(currentSlide);
}

function prevSlide() {
  currentSlide--;
  if (currentSlide < 1) {
    currentSlide = 3;
  }
  showSlide(currentSlide);
}
