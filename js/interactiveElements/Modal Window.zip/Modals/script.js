const modalRef = document.getElementById("modalOverlay");
const bodyRef = document.getElementById("body");

function openModal() {
  modalRef.classList.add("showElement");
  bodyRef.classList.add("noScrolling");
}

function closeModal() {
  modalRef.classList.remove("showElement");
  bodyRef.classList.remove("noScrolling");
}
