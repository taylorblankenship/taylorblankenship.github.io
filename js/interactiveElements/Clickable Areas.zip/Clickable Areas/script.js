function showMessage(text) {
  document.getElementById("messageBox").innerText = text;
}
