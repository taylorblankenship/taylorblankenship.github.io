let score = 0;

function answerQuestion1(answer) {
  if (answer === "orange") {
    score += 1;
  }

  document.getElementById("question1").classList.remove("active");
  document.getElementById("question2").classList.add("active");
}

function answerQuestion2(answer) {
  if (answer === "honey") {
    score += 1;
  }

  document.getElementById("question2").classList.remove("active");
  document.getElementById("question3").classList.add("active");
}

function answerQuestion3(answer) {
  if (answer === "earth") {
    score += 1;
  }

  document.getElementById("question3").classList.remove("active");
  document.getElementById("result").classList.add("active");
  document.getElementById("scoreText").textContent =
    score + " out of 3 correct!";
}
